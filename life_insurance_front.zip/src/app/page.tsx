'use client'

// This component won't be displayed if redirection occurs
export default function Page() {
  return null
}
