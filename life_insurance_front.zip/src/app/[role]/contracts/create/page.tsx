'use client'

import { InsuranceContractForm } from '@/modules/contracts/pages/ContractPage'

export default function ContractsManagementPage() {
  return (
    <div className="container py-2">
      <InsuranceContractForm />
    </div>
  )
}
