export default function ContractsPage() {}
