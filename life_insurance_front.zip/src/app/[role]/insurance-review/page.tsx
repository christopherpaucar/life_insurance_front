'use client'

import { ContractList } from '../../../modules/contracts/components/ContractList'

export default function InsuranceReview() {
  return (
    <div>
      <ContractList />
    </div>
  )
}
