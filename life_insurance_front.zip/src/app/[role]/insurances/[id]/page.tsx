'use client'
import { InsuranceContractForm } from '@/modules/contracts/pages/ContractPage'
import React from 'react'

export default function Page() {
  return <InsuranceContractForm />
}
